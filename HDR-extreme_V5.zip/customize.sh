#Print welcome message
ui_print "- Enabling Highest Graphics in Bgmi/pubg without fucking data"
ui_print "- Enabling GPU tweaks"
ui_print "- By Alioth2004"
