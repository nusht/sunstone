#!/system/bin/sh

# Low-end HyperOS Optimization
# This script is intended to modify deviceLevelList to flagship devices value
# First, let's defind the mod location
MODDIR=${0%/*}

# Now, this script will be executed in post-fs-data mode
settings put system deviceLevelList "v:1;c:3;g:3"

# Made by LLions Mods